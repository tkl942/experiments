function main_case_study()
clc; clear; close all;

% ============================================================
% 25-state UAV case from the paper
% ============================================================
G = build_uav_automaton_real();

fprintf('Running 25-state UAV case study...\n');
fprintf('|X| = %d, |T| = %d\n', G.n, numel(G.from));

% ============================================================
% 1) Baseline (no attack)
% ============================================================
baseline = check_robust_prognosability_under_attack(G, {}, {});
fprintf('\n=== Baseline (no attack) ===\n');
print_result(baseline);

% ============================================================
% 2) Attack case from the paper
% ============================================================
Eera = {'h'};
Eins = {'g','d'};

attackCase = check_robust_prognosability_under_attack(G, Eera, Eins);
fprintf('\n=== Under attack: Eera={h}, Eins={g,d} ===\n');
print_result(attackCase);

% ============================================================
% 3) Check the illustrative counterexample used in the paper
% ============================================================
fprintf('\n=== Paper counterexample check ===\n');
verify_paper_counterexample(G);

end

%% ====================================================================
%% Main verification pipeline
%% ====================================================================
function R = check_robust_prognosability_under_attack(G, Eera, Eins)

faultEvent = 'f';

% 1) Build labeled plant G_l
Gl = build_labeled_plant(G, faultEvent);

% 2) Build faulty part G_F and normal part G_N
GF = build_faulty_part(Gl);
GN = build_normal_part(Gl);

% 3) Build faulty automaton under attack G_FA
GFA = build_attack_faulty_automaton(GF, Eins, Eera);

% Keep only faulty words ending with f
postFault = false(GFA.n,1);
for i = 1:numel(GFA.from)
    if strcmp(GFA.event{i}, faultEvent)
        postFault(GFA.to(i)) = true;
    end
end
GFA = remove_outgoing_from_states(GFA, find(postFault));
GFA.marked = postFault;
GFA = trim_automaton(GFA);

% 4) Build normal automaton under attack G_NA
GNA = build_attack_normal_automaton(GN, Eins, Eera);

% Mark states in nontrivial SCCs using events in E_w \ E_-
Eminus = strcat(Eera, '_-');
GNA = keep_prefixes_to_nontrivial_scc(GNA, Eminus);

% 5) Build attack-aware verifier G_VA
Ea = union_cell(G.Eo, union_cell(strcat(Eins,'_+'), strcat(Eera,'_-')));
GVA = build_attack_aware_parallel(GFA, GNA, Ea, G.Euo);

% 6) Bad states = product states whose first component is F-labeled
bad = false(GVA.n,1);
for i = 1:GVA.n
    nm = GVA.state_names{i};
    parts = strsplit(nm, '|');
    left = parts{1};
    if ~isempty(left) && left(end) == 'F'
        bad(i) = true;
    end
end

% 7) Witness path to one bad state
[wPathStates, wPathEvents] = find_witness_path(GVA, bad);

R.is_robust = ~any(bad);
R.bad_mask = bad;
R.bad_states = GVA.state_names(bad);
R.witness_states = wPathStates;
R.witness_events = wPathEvents;
R.GF = GF;
R.GN = GN;
R.GFA = GFA;
R.GNA = GNA;
R.GVA = GVA;

end

%% ====================================================================
%% 25-state UAV case-study
%% ====================================================================
function G = build_uav_automaton_real()

nX = 25;
state_names = arrayfun(@num2str, 1:nX, 'UniformOutput', false);
events = {'a','b','c','d','e','f','g','h','w'};

G = new_automaton(state_names, events, '1');
G.Euo = {'a','f'};
G.Eo  = setdiff(events, G.Euo, 'stable');
G.Ef  = {'f'};

T = {
    % ---------- Row 1 ----------
    '1','b','2';
    '2','c','3';
    '3','e','4';
    '4','h','5';

    % ---------- Row 2 ----------
    '6','b','7';
    '7','c','8';
    '8','e','9';
    '9','h','10';

    % ---------- Row 3 ----------
    '11','b','12';
    '12','h','13';
    '13','e','14';
    '14','h','15';

    % ---------- Row 4 ----------
    '16','b','17';
    '17','d','18';
    '18','e','19';
    '19','h','20';

    % ---------- Row 5 ----------
    '21','b','22';
    '22','c','23';
    '23','e','24';
    '24','h','25';

    % ---------- Column 1 ----------
    '1','a','6';
    '6','d','11';
    '11','g','16';
    '16','w','21';

    % ---------- Column 2 ----------
    '2','a','7';
    '7','d','12';
    '12','g','17';
    '17','w','22';

    % ---------- Column 3 ----------
    '3','d','8';
    '8','d','13';
    '13','g','18';
    '18','w','23';

    % ---------- Column 4 ----------
    '4','a','9';
    '9','d','14';
    '14','f','19';
    '19','w','24';

    % ---------- Column 5 ----------
    '5','a','10';
    '10','d','15';
    '15','f','20';
    '20','w','25';

    % ---------- Self-loop ----------
    '25','w','25';
};

for i = 1:size(T,1)
    G = add_transition(G, T{i,1}, T{i,2}, T{i,3});
end

G = finalize_automaton(G);

end

%% ====================================================================
%% Labeled plant G_l: state names like "12N", "19F"
%% ====================================================================
function Gl = build_labeled_plant(G, faultEvent)

names = {};
from = [];
to = [];
event = {};

queue = {};
head = 1;

x0_key = [G.state_names{G.x0}, 'N'];
queue{end+1} = x0_key;
names{end+1} = x0_key;

while head <= numel(queue)
    curKey = queue{head};
    head = head + 1;

    [xName, lbl] = split_labeled_state(curKey);
    x = state_index(G, xName);
    curIdx = find(strcmp(names, curKey), 1);

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        t = outIdx(k);
        e = G.event{t};
        y = G.to(t);

        newLbl = lbl;
        if strcmp(e, faultEvent) || strcmp(lbl, 'F')
            newLbl = 'F';
        end

        nxtKey = [G.state_names{y}, newLbl];

        if ~contains_cell(names, nxtKey)
            names{end+1} = nxtKey; %#ok<AGROW>
            queue{end+1} = nxtKey; %#ok<AGROW>
        end

        nxtIdx = find(strcmp(names, nxtKey), 1);

        from(end+1,1) = curIdx; %#ok<AGROW>
        to(end+1,1) = nxtIdx; %#ok<AGROW>
        event{end+1,1} = e; %#ok<AGROW>
    end
end

Gl = new_automaton(names, G.events, x0_key);
Gl.from = from;
Gl.to = to;
Gl.event = event;
Gl = finalize_automaton(Gl);

end

%% ====================================================================
%% Faulty part G_F
%% ====================================================================
function GF = build_faulty_part(Gl)

isFault = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'F'
        isFault(i) = true;
    end
end

Gl.marked = isFault;
GF = coaccessible_subautomaton(Gl);

end

%% ====================================================================
%% Normal part G_N
%% ====================================================================
function GN = build_normal_part(Gl)

keep = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'N'
        keep(i) = true;
    end
end

GN = induced_subautomaton(Gl, find(keep));

mask = true(numel(GN.event),1);
for i = 1:numel(GN.event)
    if strcmp(GN.event{i}, 'f')
        mask(i) = false;
    end
end

GN.from  = GN.from(mask);
GN.to    = GN.to(mask);
GN.event = GN.event(mask);
GN = finalize_automaton(GN);

GN.marked = true(GN.n,1);

end

%% ====================================================================
%% Faulty automaton under attack G_FA
%% ====================================================================
function GFA = build_attack_faulty_automaton(GF, Eins, Eera)

Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GF.events, union_cell(Eplus, Eminus));

GFA = new_automaton(GF.state_names, Ew, GF.state_names{GF.x0});
GFA.from = GF.from;
GFA.to   = GF.to;
GFA.event = GF.event;

% insertion self-loops at all states
for x = 1:GF.n
    for i = 1:numel(Eins)
        GFA = add_transition(GFA, GF.state_names{x}, [Eins{i}, '_+'], GF.state_names{x});
    end
end

% erasure parallel transitions
for t = 1:numel(GF.from)
    e = GF.event{t};
    if ismember(e, Eera)
        GFA = add_transition(GFA, GF.state_names{GF.from(t)}, [e, '_-'], GF.state_names{GF.to(t)});
    end
end

GFA = finalize_automaton(GFA);

end

%% ====================================================================
%% Normal automaton under attack G_NA
%% ====================================================================
function GNA = build_attack_normal_automaton(GN, Eins, Eera)

Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GN.events, union_cell(Eplus, Eminus));

GNA = new_automaton(GN.state_names, Ew, GN.state_names{GN.x0});
GNA.from = GN.from;
GNA.to   = GN.to;
GNA.event = GN.event;

% erasure self-loops at all states
for x = 1:GN.n
    for i = 1:numel(Eera)
        GNA = add_transition(GNA, GN.state_names{x}, [Eera{i}, '_-'], GN.state_names{x});
    end
end

% insertion transitions in parallel
for t = 1:numel(GN.from)
    e = GN.event{t};
    if ismember(e, Eins)
        GNA = add_transition(GNA, GN.state_names{GN.from(t)}, [e, '_+'], GN.state_names{GN.to(t)});
    end
end

GNA = finalize_automaton(GNA);

end

%% ====================================================================
%% Keep prefixes that can reach nontrivial SCCs in G_NA using E_w \ E_-
%% ====================================================================
function Gout = keep_prefixes_to_nontrivial_scc(GNA, Eminus)

mask = true(numel(GNA.from),1);
for i = 1:numel(GNA.from)
    if ismember(GNA.event{i}, Eminus)
        mask(i) = false;
    end
end

A = sparse(GNA.from(mask), GNA.to(mask), 1, GNA.n, GNA.n);
DG = digraph(A);

comp = conncomp(DG, 'Type', 'strong');
numC = max(comp);

marked = false(GNA.n,1);

for c = 1:numC
    nodes = find(comp == c);

    if numel(nodes) > 1
        marked(nodes) = true;
    else
        x = nodes(1);
        if A(x,x) ~= 0
            marked(x) = true;
        end
    end
end

GNA.marked = marked;
Gout = coaccessible_subautomaton(GNA);

end

%% ====================================================================
%% Attack-aware parallel composition
%% ====================================================================
function GVA = build_attack_aware_parallel(G1, G2, Ea, Euo)

names = {};
from = [];
to = [];
event = {};

queue = {};
head = 1;

x0Key = [G1.state_names{G1.x0}, '|', G2.state_names{G2.x0}];
names{1} = x0Key;
queue{1} = x0Key;

while head <= numel(queue)
    curKey = queue{head};
    head = head + 1;

    parts = strsplit(curKey, '|');
    x1 = state_index(G1, parts{1});
    x2 = state_index(G2, parts{2});
    curIdx = find(strcmp(names, curKey), 1);

    % synchronized on Ea
    for i = 1:numel(Ea)
        e = Ea{i};
        post1 = post_states(G1, x1, e);
        post2 = post_states(G2, x2, e);

        for a = 1:numel(post1)
            for b = 1:numel(post2)
                nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{post2(b)}];
                if ~contains_cell(names, nxtKey)
                    names{end+1} = nxtKey; %#ok<AGROW>
                    queue{end+1} = nxtKey; %#ok<AGROW>
                end
                nxtIdx = find(strcmp(names, nxtKey), 1);

                from(end+1,1) = curIdx; %#ok<AGROW>
                to(end+1,1) = nxtIdx; %#ok<AGROW>
                event{end+1,1} = e; %#ok<AGROW>
            end
        end
    end

    % asynchronous on Euo
    for i = 1:numel(Euo)
        e = Euo{i};

        post1 = post_states(G1, x1, e);
        for a = 1:numel(post1)
            nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{x2}];
            if ~contains_cell(names, nxtKey)
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end
            nxtIdx = find(strcmp(names, nxtKey), 1);

            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end

        post2 = post_states(G2, x2, e);
        for b = 1:numel(post2)
            nxtKey = [G1.state_names{x1}, '|', G2.state_names{post2(b)}];
            if ~contains_cell(names, nxtKey)
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end
            nxtIdx = find(strcmp(names, nxtKey), 1);

            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end
    end
end

allEvents = union_cell(Ea, Euo);
GVA = new_automaton(names, allEvents, x0Key);
GVA.from = from;
GVA.to = to;
GVA.event = event;
GVA = finalize_automaton(GVA);

end

%% ====================================================================
%% Witness path search
%% ====================================================================
function [pathStates, pathEvents] = find_witness_path(G, targetMask)

pathStates = {};
pathEvents = {};

targets = find(targetMask);
if isempty(targets)
    return;
end

goal = targets(1);

visited = false(G.n,1);
predState = zeros(G.n,1);
predEvent = cell(G.n,1);

Q = G.x0;
visited(G.x0) = true;
head = 1;

while head <= numel(Q)
    x = Q(head);
    head = head + 1;

    if x == goal
        break;
    end

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        t = outIdx(k);
        y = G.to(t);
        if ~visited(y)
            visited(y) = true;
            predState(y) = x;
            predEvent{y} = G.event{t};
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end

if ~visited(goal)
    return;
end

seqStates = goal;
seqEvents = {};
cur = goal;

while cur ~= G.x0
    seqEvents = [{predEvent{cur}}, seqEvents];
    cur = predState(cur);
    seqStates = [cur, seqStates]; %#ok<AGROW>
end

pathStates = G.state_names(seqStates);
pathEvents = seqEvents;

end

%% ====================================================================
%% Paper counterexample check
%% ====================================================================
function verify_paper_counterexample(G)

sigma = {'a','b','d','h','e','f'};
t     = {'a','b','d','h','e'};
sa    = {'b','d','h_-','g_+','d_+','e'};
u     = {'a','b','d','g','d','e'};

[ok_sigma, path_sigma] = trace_word_in_plant(G, sigma);
[ok_u, path_u] = trace_word_in_plant(G, u);

obs_t = project_word(t, G.Eo);
corr_sa = receiver_mask(sa);
obs_u = project_word(u, G.Eo);

fprintf('sigma = %s\n', word_to_str(sigma));
fprintf('t     = %s\n', word_to_str(t));
fprintf('s_a   = %s\n', word_to_str(sa));
fprintf('u     = %s\n\n', word_to_str(u));

fprintf('sigma in L(G): %s\n', ternary(ok_sigma,'YES','NO'));
fprintf('u in L(G): %s\n', ternary(ok_u,'YES','NO'));

if ok_sigma
    fprintf('Path of sigma:\n');
    disp(path_sigma);
end

if ok_u
    fprintf('Path of u:\n');
    disp(path_u);
end

fprintf('P_o(t)    = %s\n', word_to_str(obs_t));
fprintf('hatP(s_a) = %s\n', word_to_str(corr_sa));
fprintf('P_o(u)    = %s\n', word_to_str(obs_u));
fprintf('hatP(s_a)=P_o(u): %s\n', ternary(isequal(corr_sa, obs_u),'YES','NO'));

if ok_u
    lastStateName = path_u{end};
    lastStateIdx = state_index(G, lastStateName);

    [found_v, v] = find_normal_continuation_no_fault(G, lastStateIdx, 3, 8);
    if found_v
        fprintf('One normal continuation without f: v = %s\n', word_to_str(v));
    else
        fprintf('No normal continuation without f found in the search bound.\n');
    end
end

fprintf('\nConclusion: the paper counterexample is %s.\n', ...
    ternary(ok_sigma && ok_u && isequal(corr_sa, obs_u), 'VALID', 'NOT VALID'));

end

function [ok, statePath] = trace_word_in_plant(G, word)
[ok, statePath] = trace_word_from_state(G, G.x0, word);
end

function [ok, statePath] = trace_word_from_state(G, x0, word)

cur = x0;
statePath = {G.state_names{cur}};
ok = true;

for i = 1:numel(word)
    e = word{i};
    nxt = next_state_det(G, cur, e);
    if isempty(nxt)
        ok = false;
        return;
    end
    cur = nxt;
    statePath{end+1} = G.state_names{cur}; %#ok<AGROW>
end

end

function nxt = next_state_det(G, x, e)

nxt = [];
outIdx = G.out{x};

for k = 1:numel(outIdx)
    t = outIdx(k);
    if strcmp(G.event{t}, e)
        nxt = G.to(t);
        return;
    end
end

end

function obs = project_word(word, Eo)

obs = {};
for i = 1:numel(word)
    if ismember(word{i}, Eo)
        obs{end+1} = word{i}; %#ok<AGROW>
    end
end

end

function obs = receiver_mask(word)

obs = {};
for i = 1:numel(word)
    e = word{i};

    if ends_with(e, '_-')
        % erased event: invisible to receiver
        continue;
    elseif ends_with(e, '_+')
        % inserted event: receiver sees the underlying event
        obs{end+1} = e(1:end-2); %#ok<AGROW>
    else
        % normal event passed to receiver mask
        obs{end+1} = e; %#ok<AGROW>
    end
end

end

function tf = ends_with(s, suffix)

if length(s) < length(suffix)
    tf = false;
    return;
end

tf = strcmp(s(end-length(suffix)+1:end), suffix);

end

function [found, word] = find_normal_continuation_no_fault(G, x0, minLen, maxLen)

found = false;
word = {};

queueStates = x0;
queueWords = {{}};
head = 1;

while head <= numel(queueStates)
    x = queueStates(head);
    w = queueWords{head};
    head = head + 1;

    if numel(w) >= minLen
        found = true;
        word = w;
        return;
    end

    if numel(w) >= maxLen
        continue;
    end

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        t = outIdx(k);
        e = G.event{t};

        if strcmp(e, 'f')
            continue;
        end

        y = G.to(t);
        queueStates(end+1) = y; %#ok<AGROW>
        queueWords{end+1} = [w, {e}]; %#ok<AGROW>
    end
end

end

function s = word_to_str(word)

if isempty(word)
    s = 'epsilon';
    return;
end

s = '';
for i = 1:numel(word)
    s = [s, word{i}]; %#ok<AGROW>
end

end

%% ====================================================================
%% Printing
%% ====================================================================
function print_result(R)

fprintf('Robust prognosability: %s\n', ternary(R.is_robust,'YES','NO'));
fprintf('|GF|=%d, |GN|=%d, |GFA|=%d, |GNA|=%d, |GVA|=%d\n', ...
    R.GF.n, R.GN.n, R.GFA.n, R.GNA.n, R.GVA.n);
fprintf('|T_FA|=%d, |T_NA|=%d, |T_VA|=%d\n', ...
    numel(R.GFA.from), numel(R.GNA.from), numel(R.GVA.from));

if ~R.is_robust
    fprintf('Bad states found:\n');
    disp(R.bad_states(:));

    fprintf('One witness path (states):\n');
    disp(R.witness_states(:)');

    fprintf('One witness path (events):\n');
    disp(R.witness_events(:)');
end

end

%% ====================================================================
%% Generic automaton utilities
%% ====================================================================
function G = new_automaton(state_names, events, x0_name)

G.state_names = state_names(:)';
G.events = events(:)';
G.n = numel(state_names);
G.x0 = find(strcmp(G.state_names, x0_name), 1);

G.from = [];
G.to = [];
G.event = {};
G.marked = false(G.n,1);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);

end

function G = add_transition(G, fromName, e, toName)

fi = state_index(G, fromName);
ti = state_index(G, toName);

G.from(end+1,1) = fi;
G.to(end+1,1) = ti;
G.event{end+1,1} = e;

end

function idx = state_index(G, name)

idx = find(strcmp(G.state_names, name), 1);
if isempty(idx)
    error('State "%s" not found.', name);
end

end

function G = finalize_automaton(G)

G.n = numel(G.state_names);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);

for i = 1:numel(G.from)
    G.out{G.from(i)}(end+1) = i;
    G.in{G.to(i)}(end+1) = i;
end

if numel(G.marked) ~= G.n
    G.marked = false(G.n,1);
end

end

function vec = post_states(G, x, e)

vec = [];
outIdx = G.out{x};
for k = 1:numel(outIdx)
    t = outIdx(k);
    if strcmp(G.event{t}, e)
        vec(end+1) = G.to(t); %#ok<AGROW>
    end
end

end

function Gsub = induced_subautomaton(G, keepIdx)

keepIdx = unique(keepIdx(:)');
map = zeros(G.n,1);
map(keepIdx) = 1:numel(keepIdx);

if map(G.x0) == 0
    Gsub = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gsub.marked = false(1,1);
    Gsub = finalize_automaton(Gsub);
    return;
end

x0_name = G.state_names{G.x0};
Gsub = new_automaton(G.state_names(keepIdx), G.events, x0_name);
Gsub.marked = G.marked(keepIdx);

for i = 1:numel(G.from)
    if map(G.from(i)) > 0 && map(G.to(i)) > 0
        Gsub.from(end+1,1) = map(G.from(i)); %#ok<AGROW>
        Gsub.to(end+1,1) = map(G.to(i)); %#ok<AGROW>
        Gsub.event{end+1,1} = G.event{i}; %#ok<AGROW>
    end
end

Gsub = finalize_automaton(Gsub);

end

function Gacc = accessible_subautomaton(G)

vis = false(G.n,1);
Q = G.x0;
vis(G.x0) = true;
head = 1;

while head <= numel(Q)
    x = Q(head);
    head = head + 1;

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        y = G.to(outIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end

Gacc = induced_subautomaton(G, find(vis));

end

function Gco = coaccessible_subautomaton(G)

marked = find(G.marked);

if isempty(marked)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end

vis = false(G.n,1);
Q = marked(:)';
vis(marked) = true;
head = 1;

while head <= numel(Q)
    x = Q(head);
    head = head + 1;

    inIdx = G.in{x};
    for k = 1:numel(inIdx)
        y = G.from(inIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end

if ~vis(G.x0)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end

Gco = induced_subautomaton(G, find(vis));

end

function Gtrim = trim_automaton(G)

G1 = accessible_subautomaton(G);
Gtrim = coaccessible_subautomaton(G1);

end

function Gout = remove_outgoing_from_states(G, stateIdx)

mask = true(numel(G.from),1);
stateIdx = unique(stateIdx(:)');

for i = 1:numel(G.from)
    if ismember(G.from(i), stateIdx)
        mask(i) = false;
    end
end

Gout = G;
Gout.from = G.from(mask);
Gout.to   = G.to(mask);
Gout.event = G.event(mask);
Gout = finalize_automaton(Gout);

end

%% ====================================================================
%% Small helpers
%% ====================================================================
function tf = contains_cell(C, x)
tf = any(strcmp(C, x));
end

function out = union_cell(A, B)

if isempty(A) && isempty(B)
    out = {};
    return;
end

if isempty(A)
    out = B(:)';
    return;
end

if isempty(B)
    out = A(:)';
    return;
end

out = unique([A(:); B(:)]', 'stable');

end

function s = ternary(cond, a, b)
if cond
    s = a;
else
    s = b;
end
end

function [xName, lbl] = split_labeled_state(key)
lbl = key(end);
xName = key(1:end-1);
end