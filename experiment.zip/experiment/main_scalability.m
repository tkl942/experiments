function main_scalability()
clc; clear; close all;
rng(1);

% ============================================================
% Experiment configuration
% N = number of plant states |X|
% ============================================================
N_list = [40 60 80 100 120];
numSamples = 10;
maxTriesPerSample = 250;

results = struct();
row = 0;

fprintf('Running scalability experiment (prog first, then robustprog under attack)...\n');

for nIdx = 1:numel(N_list)
    N = N_list(nIdx);
    fprintf('\n=== N = %d ===\n', N);

    for s = 1:numSamples
        collected = false;
        tries = 0;

        while ~collected && tries < maxTriesPerSample
            tries = tries + 1;

            % 1) Generate a nominally strong plant
            G = generate_structured_prognosable_plant(N);

            % 2) Keep only plants with prog = 1
            R0 = check_robust_prognosability_under_attack(G, {}, {});
            terminatedNominal = isfield(R0.GVA, 'terminatedEarly') && R0.GVA.terminatedEarly;

            if terminatedNominal || ~R0.is_robust
                continue;
            end

            % 3) Generate a nonempty attack
            [Eera, Eins, attackMode] = generate_attack_scenario(G);

            % 4) Check robust prognosability under attack
            tStart = tic;
            R1 = check_robust_prognosability_under_attack(G, Eera, Eins);
            attackTime = toc(tStart);

            terminatedAttack = isfield(R1.GVA, 'terminatedEarly') && R1.GVA.terminatedEarly;

            % 5) Reject oversized or capped verifiers and resample silently
            tooLarge = terminatedAttack || R1.GVA.n > 2800 || numel(R1.GVA.from) > 22000;
            if tooLarge
                continue;
            end

            collected = true;

            row = row + 1;
            results(row).N = G.n;
            results(row).numTrans = numel(G.from);
            results(row).numEvents = numel(G.events);
            results(row).numObs = numel(G.Eo);
            results(row).numUnobs = numel(G.Euo);
            results(row).numEra = numel(Eera);
            results(row).numIns = numel(Eins);
            results(row).prog = R0.is_robust;
            results(row).robustprog = R1.is_robust;
            results(row).timeAttack = attackTime;
            results(row).GF = R1.GF.n;
            results(row).GN = R1.GN.n;
            results(row).GFA = R1.GFA.n;
            results(row).GNA = R1.GNA.n;
            results(row).GVA = R1.GVA.n;
            results(row).TVA = numel(R1.GVA.from);
            results(row).attackMode = {attackMode};
            results(row).Eera = {strjoin(Eera, ',')};
            results(row).Eins = {strjoin(Eins, ',')};

            fprintf(['  sample %2d: |T|=%4d, time=%.4f s, |GVA|=%4d, |T_VA|=%5d, ' ...
                     'prog=%d, robustprog=%d, mode=%s, |Eera|=%d, |Eins|=%d\n'], ...
                s, numel(G.from), attackTime, R1.GVA.n, numel(R1.GVA.from), ...
                R0.is_robust, R1.is_robust, attackMode, numel(Eera), numel(Eins));
        end

        if ~collected
            fprintf('  sample %2d: no admissible instance found within %d tries\n', s, maxTriesPerSample);
        end
    end
end

if isempty(results)
    error('No valid samples were collected.');
end

T = struct2table(results);

disp(' ');
disp('=== Raw results (first few rows) ===');
disp(T(1:min(12,height(T)), :));

summary_tbl = make_summary_table(T);
disp(' ');
disp('=== Aggregated summary ===');
disp(summary_tbl);

plot_scalability_results(T);

writetable(T, 'scalability_results.csv');
writetable(summary_tbl, 'scalability_summary.csv');

fprintf('\nSaved:\n');
fprintf('  scalability_results.csv\n');
fprintf('  scalability_summary.csv\n');

end

%% ============================================================
%% Structured random plant generator
%% Purpose:
%%   Build a plant that is nominally prognosable by construction
%%   but may lose robustness under a critical attack.
%%
%% Core vulnerable pattern:
%%   sigma = a b d h e f
%%   u     = a b d g d e
%%
%% Faulty side:
%%   1 -a-> 2 -b-> 3 -d-> 4 -h-> 5 -e-> 6 -f-> 7
%%
%% Normal side:
%%   4 -g-> 8 -d-> 9 -e-> 10
%%
%% Additional normal side:
%%   4 -c-> 11 -d-> 12 -e-> 13
%%
%% Rich normal SCC:
%%   10,13,14,15,16,17
%% ============================================================
function G = generate_structured_prognosable_plant(N)

if N < 18
    error('N must be at least 18.');
end

events = {'a','b','c','d','e','f','g','h','w'};
state_names = arrayfun(@num2str, 1:N, 'UniformOutput', false);

G = new_automaton(state_names, events, '1');
G.Euo = {'a','f'};
G.Eo = setdiff(events, G.Euo, 'stable');
G.Ef = {'f'};

used = false(N, numel(events));

% ------------------------------------------------------------
% Core structure
% ------------------------------------------------------------
coreT = {
    % shared prefix
    '1','a','2';
    '2','b','3';
    '3','d','4';

    % faulty branch
    '4','h','5';
    '5','e','6';
    '6','f','7';

    % normal branch 1
    '4','g','8';
    '8','d','9';
    '9','e','10';

    % normal branch 2
    '4','c','11';
    '11','d','12';
    '12','e','13';

    % normal SCC
    '10','w','14';
    '14','c','15';
    '15','w','16';
    '16','e','17';
    '17','w','10';

    '13','w','15';
    '14','e','13';
    '16','c','10';
    '17','e','14';
};

for i = 1:size(coreT,1)
    G = add_transition(G, coreT{i,1}, coreT{i,2}, coreT{i,3});
    x = str2double(coreT{i,1});
    e = coreT{i,2};
    used(x, event_pos(G.events, e)) = true;
end

% ------------------------------------------------------------
% Filler expansion
% Most new states are attached to the normal side.
% Only a smaller fraction expands the ambiguous side.
% ------------------------------------------------------------
ambiguousSeeds = [3 4 5 8 9 11 12];
normalSeeds    = [10 13 14 15 16 17];
parentCandidates = [ambiguousSeeds, normalSeeds];

attachPoolAmb = {'b','c','d','e','g','h'};
attachPoolNor = {'b','c','d','e','w'};

for x = 18:N
    % 30% ambiguous side, 70% normal side
    if rand < 0.30
        seedPool = ambiguousSeeds;
        attachPool = attachPoolAmb;
    else
        seedPool = normalSeeds;
        attachPool = attachPoolNor;
    end

    possibleParents = [];
    possibleEvents = {};

    for p = 1:numel(seedPool)
        parent = seedPool(p);
        avail = {};
        for k = 1:numel(attachPool)
            e = attachPool{k};
            if ~used(parent, event_pos(G.events, e))
                avail{end+1} = e; %#ok<AGROW>
            end
        end
        if ~isempty(avail)
            possibleParents(end+1) = parent; %#ok<AGROW>
            possibleEvents{end+1} = avail; %#ok<AGROW>
        end
    end

    if isempty(possibleParents)
        for p = 1:numel(parentCandidates)
            parent = parentCandidates(p);
            avail = {};
            for k = 1:numel(G.events)
                e = G.events{k};
                if ~strcmp(e,'f') && ~used(parent, event_pos(G.events, e))
                    avail{end+1} = e; %#ok<AGROW>
                end
            end
            if ~isempty(avail)
                possibleParents(end+1) = parent; %#ok<AGROW>
                possibleEvents{end+1} = avail; %#ok<AGROW>
            end
        end
    end

    if isempty(possibleParents)
        break;
    end

    idx = randi(numel(possibleParents));
    parent = possibleParents(idx);
    avail = possibleEvents{idx};
    eAttach = avail{randi(numel(avail))};

    G = add_transition(G, num2str(parent), eAttach, num2str(x));
    used(parent, event_pos(G.events, eAttach)) = true;

    % 85% return to normal SCC, 15% to overlap region
    if rand < 0.85
        tgtPool = normalSeeds;
    else
        tgtPool = [8 9 11 12 14 15];
    end

    returnCandidates = {'w','c','e','d'};
    for kk = randperm(numel(returnCandidates))
        er = returnCandidates{kk};
        if ~used(x, event_pos(G.events, er))
            tgt = tgtPool(randi(numel(tgtPool)));
            G = add_transition(G, num2str(x), er, num2str(tgt));
            used(x, event_pos(G.events, er)) = true;
            break;
        end
    end

    % lower extra-edge probability to avoid over-expansion
    if rand < 0.20
        extraCandidates = {'b','c','d','e','g','h','w'};
        for kk = randperm(numel(extraCandidates))
            e2 = extraCandidates{kk};
            if ~used(x, event_pos(G.events, e2))
                if rand < 0.75
                    tgt2Pool = normalSeeds;
                else
                    tgt2Pool = [4 5 8 9 11 12 14 15];
                end
                tgt2 = tgt2Pool(randi(numel(tgt2Pool)));
                G = add_transition(G, num2str(x), e2, num2str(tgt2));
                used(x, event_pos(G.events, e2)) = true;
                break;
            end
        end
    end

    parentCandidates(end+1) = x; %#ok<AGROW>

    if rand < 0.25
        ambiguousSeeds(end+1) = x; %#ok<AGROW>
    else
        normalSeeds(end+1) = x; %#ok<AGROW>
    end
end

G = finalize_automaton(G);

end

%% ============================================================
%% Attack scenario generator
%% Always nonempty attack sets.
%% Most attacks are benign or medium.
%% A smaller fraction are critical:
%%   Eera = {h}, Eins = {g,d}
%% ============================================================
function [Eera, Eins, attackMode] = generate_attack_scenario(G)

pCritical = 0.10;
pMedium   = 0.20;

r = rand;

if r < pCritical
    Eera = {'h'};
    Eins = {'g','d'};
    attackMode = 'critical';

elseif r < pCritical + pMedium
    % medium attacks: touch one key event + one safe event
    eraPool = intersect(G.Eo, {'h','e'});
    insPool = intersect(G.Eo, {'g','d','e','w'});

    if isempty(eraPool), eraPool = G.Eo; end
    if isempty(insPool), insPool = G.Eo; end

    Eera = eraPool(randperm(numel(eraPool), 1));

    if numel(insPool) >= 2
        perm = randperm(numel(insPool), 2);
        Eins = insPool(perm);
    else
        Eins = insPool(randperm(numel(insPool), 1));
    end

    attackMode = 'medium';

else
    % benign attacks: avoid the key vulnerable set as much as possible
    benignEraCandidates = intersect(G.Eo, {'c','e','w'});
    benignInsCandidates = intersect(G.Eo, {'b','c','e','w'});

    if isempty(benignEraCandidates), benignEraCandidates = G.Eo; end
    if isempty(benignInsCandidates), benignInsCandidates = G.Eo; end

    Eera = benignEraCandidates(randperm(numel(benignEraCandidates), 1));
    Eins = benignInsCandidates(randperm(numel(benignInsCandidates), 1));

    attackMode = 'benign';
end

end

%% ============================================================
%% Summary table
%% ============================================================
function S = make_summary_table(T)

Ns = unique(T.N);
numValid = zeros(numel(Ns),1);
meanTime = zeros(numel(Ns),1);
stdTime  = zeros(numel(Ns),1);
meanGVA  = zeros(numel(Ns),1);
stdGVA   = zeros(numel(Ns),1);
meanTVA  = zeros(numel(Ns),1);
stdTVA   = zeros(numel(Ns),1);
meanProg = zeros(numel(Ns),1);
meanRobustProg = zeros(numel(Ns),1);
criticalFrac = zeros(numel(Ns),1);

for i = 1:numel(Ns)
    idx = (T.N == Ns(i));
    numValid(i) = sum(idx);
    meanTime(i) = mean(T.timeAttack(idx));
    stdTime(i)  = std(T.timeAttack(idx));
    meanGVA(i)  = mean(T.GVA(idx));
    stdGVA(i)   = std(T.GVA(idx));
    meanTVA(i)  = mean(T.TVA(idx));
    stdTVA(i)   = std(T.TVA(idx));
    meanProg(i) = mean(T.prog(idx));
    meanRobustProg(i) = mean(T.robustprog(idx));
    criticalFrac(i) = mean(strcmp(T.attackMode(idx), 'critical'));
end

S = table(Ns, numValid, meanTime, stdTime, meanGVA, stdGVA, meanTVA, stdTVA, ...
    meanProg, meanRobustProg, criticalFrac, ...
    'VariableNames', {'N','numSamples','meanAttackTime','stdAttackTime', ...
    'meanGVA','stdGVA','meanTVA','stdTVA', ...
    'meanProgRatio','meanRobustProgRatio','criticalAttackFraction'});

end

%% ============================================================
%% Main verification pipeline
%% ============================================================
function R = check_robust_prognosability_under_attack(G, Eera, Eins)

faultEvent = 'f';

Gl = build_labeled_plant(G, faultEvent);
GF = build_faulty_part(Gl);
GN = build_normal_part(Gl);

GFA = build_attack_faulty_automaton(GF, Eins, Eera);

postFault = false(GFA.n,1);
for i = 1:numel(GFA.from)
    if strcmp(GFA.event{i}, faultEvent)
        postFault(GFA.to(i)) = true;
    end
end
GFA = remove_outgoing_from_states(GFA, find(postFault));
GFA.marked = postFault;
GFA = trim_automaton(GFA);

GNA = build_attack_normal_automaton(GN, Eins, Eera);

Eminus = strcat(Eera, '_-');
GNA = keep_prefixes_to_nontrivial_scc(GNA, Eminus);

Ea = union_cell(G.Eo, union_cell(strcat(Eins,'_+'), strcat(Eera,'_-')));
GVA = build_attack_aware_parallel(GFA, GNA, Ea, G.Euo);

bad = false(GVA.n,1);
for i = 1:GVA.n
    nm = GVA.state_names{i};
    parts = strsplit(nm, '|');
    left = parts{1};
    if ~isempty(left) && left(end) == 'F'
        bad(i) = true;
    end
end

R.is_robust = ~any(bad);
R.bad_mask = bad;
R.GF = GF;
R.GN = GN;
R.GFA = GFA;
R.GNA = GNA;
R.GVA = GVA;

end

%% ============================================================
%% Plotting
%% ============================================================
function plot_scalability_results(T)

Ns = unique(T.N);

meanTime = zeros(size(Ns));
stdTime  = zeros(size(Ns));
meanGVA  = zeros(size(Ns));
stdGVA   = zeros(size(Ns));
meanTVA  = zeros(size(Ns));
stdTVA   = zeros(size(Ns));
meanProg = zeros(size(Ns));
meanRobustProg = zeros(size(Ns));

for i = 1:numel(Ns)
    idx = (T.N == Ns(i));
    meanTime(i) = mean(T.timeAttack(idx));
    stdTime(i)  = std(T.timeAttack(idx));
    meanGVA(i)  = mean(T.GVA(idx));
    stdGVA(i)   = std(T.GVA(idx));
    meanTVA(i)  = mean(T.TVA(idx));
    stdTVA(i)   = std(T.TVA(idx));
    meanProg(i) = mean(T.prog(idx));
    meanRobustProg(i) = mean(T.robustprog(idx));
end

figure;
errorbar(Ns, meanTime, stdTime, 'LineWidth', 1.5, 'Marker', 'o');
xlabel('Number of plant states |X|');
ylabel('Verification time under attack (s)');
title('Runtime vs. plant size');
grid on;

figure;
errorbar(Ns, meanGVA, stdGVA, 'LineWidth', 1.5, 'Marker', 's');
xlabel('Number of plant states |X|');
ylabel('Verifier states |G_{VA}|');
title('Verifier size vs. plant size');
grid on;

figure;
errorbar(Ns, meanTVA, stdTVA, 'LineWidth', 1.5, 'Marker', '^');
xlabel('Number of plant states |X|');
ylabel('Verifier transitions |T_{VA}|');
title('Verifier transitions vs. plant size');
grid on;

figure;
plot(Ns, meanProg, 'LineWidth', 1.5, 'Marker', 'd');
hold on;
plot(Ns, meanRobustProg, 'LineWidth', 1.5, 'Marker', 'o');
xlabel('Number of plant states |X|');
ylabel('Fraction equal to 1');
legend('prog', 'robustprog', 'Location', 'best');
title('prog vs. robustprog');
grid on;

end

%% ============================================================
%% Labeled plant and attack structures
%% ============================================================
function Gl = build_labeled_plant(G, faultEvent)

names = {};
from = [];
to = [];
event = {};

queue = {};
head = 1;

x0_key = [G.state_names{G.x0}, 'N'];
queue{end+1} = x0_key;
names{end+1} = x0_key;

while head <= numel(queue)
    curKey = queue{head};
    head = head + 1;

    [xName, lbl] = split_labeled_state(curKey);
    x = state_index(G, xName);
    curIdx = find(strcmp(names, curKey), 1);

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        t = outIdx(k);
        e = G.event{t};
        y = G.to(t);

        newLbl = lbl;
        if strcmp(e, faultEvent) || strcmp(lbl, 'F')
            newLbl = 'F';
        end

        nxtKey = [G.state_names{y}, newLbl];

        if ~contains_cell(names, nxtKey)
            names{end+1} = nxtKey; %#ok<AGROW>
            queue{end+1} = nxtKey; %#ok<AGROW>
        end

        nxtIdx = find(strcmp(names, nxtKey), 1);

        from(end+1,1) = curIdx; %#ok<AGROW>
        to(end+1,1) = nxtIdx; %#ok<AGROW>
        event{end+1,1} = e; %#ok<AGROW>
    end
end

Gl = new_automaton(names, G.events, x0_key);
Gl.from = from;
Gl.to = to;
Gl.event = event;
Gl = finalize_automaton(Gl);

end

function GF = build_faulty_part(Gl)

isFault = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'F'
        isFault(i) = true;
    end
end

Gl.marked = isFault;
GF = coaccessible_subautomaton(Gl);

end

function GN = build_normal_part(Gl)

keep = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'N'
        keep(i) = true;
    end
end

GN = induced_subautomaton(Gl, find(keep));

mask = true(numel(GN.event),1);
for i = 1:numel(GN.event)
    if strcmp(GN.event{i}, 'f')
        mask(i) = false;
    end
end

GN.from  = GN.from(mask);
GN.to    = GN.to(mask);
GN.event = GN.event(mask);
GN = finalize_automaton(GN);

GN.marked = true(GN.n,1);

end

function GFA = build_attack_faulty_automaton(GF, Eins, Eera)

Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GF.events, union_cell(Eplus, Eminus));

GFA = new_automaton(GF.state_names, Ew, GF.state_names{GF.x0});
GFA.from = GF.from;
GFA.to   = GF.to;
GFA.event = GF.event;

for x = 1:GF.n
    for i = 1:numel(Eins)
        GFA = add_transition(GFA, GF.state_names{x}, [Eins{i}, '_+'], GF.state_names{x});
    end
end

for t = 1:numel(GF.from)
    e = GF.event{t};
    if ismember(e, Eera)
        GFA = add_transition(GFA, GF.state_names{GF.from(t)}, [e, '_-'], GF.state_names{GF.to(t)});
    end
end

GFA = finalize_automaton(GFA);

end

function GNA = build_attack_normal_automaton(GN, Eins, Eera)

Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GN.events, union_cell(Eplus, Eminus));

GNA = new_automaton(GN.state_names, Ew, GN.state_names{GN.x0});
GNA.from = GN.from;
GNA.to   = GN.to;
GNA.event = GN.event;

for x = 1:GN.n
    for i = 1:numel(Eera)
        GNA = add_transition(GNA, GN.state_names{x}, [Eera{i}, '_-'], GN.state_names{x});
    end
end

for t = 1:numel(GN.from)
    e = GN.event{t};
    if ismember(e, Eins)
        GNA = add_transition(GNA, GN.state_names{GN.from(t)}, [e, '_+'], GN.state_names{GN.to(t)});
    end
end

GNA = finalize_automaton(GNA);

end

function Gout = keep_prefixes_to_nontrivial_scc(GNA, Eminus)

mask = true(numel(GNA.from),1);
for i = 1:numel(GNA.from)
    if ismember(GNA.event{i}, Eminus)
        mask(i) = false;
    end
end

A = sparse(GNA.from(mask), GNA.to(mask), 1, GNA.n, GNA.n);
DG = digraph(A);

comp = conncomp(DG, 'Type', 'strong');
numC = max(comp);

marked = false(GNA.n,1);

for c = 1:numC
    nodes = find(comp == c);

    if numel(nodes) > 1
        marked(nodes) = true;
    else
        x = nodes(1);
        if A(x,x) ~= 0
            marked(x) = true;
        end
    end
end

GNA.marked = marked;
Gout = coaccessible_subautomaton(GNA);

end

function GVA = build_attack_aware_parallel(G1, G2, Ea, Euo)

MAX_STATES = 2800;
MAX_EDGES  = 22000;

names = {};
from = [];
to = [];
event = {};

queue = {};
head = 1;

x0Key = [G1.state_names{G1.x0}, '|', G2.state_names{G2.x0}];
names{1} = x0Key;
queue{1} = x0Key;

terminatedEarly = false;

while head <= numel(queue)
    if numel(names) >= MAX_STATES || numel(from) >= MAX_EDGES
        terminatedEarly = true;
        break;
    end

    curKey = queue{head};
    head = head + 1;

    parts = strsplit(curKey, '|');
    x1 = state_index(G1, parts{1});
    x2 = state_index(G2, parts{2});
    curIdx = find(strcmp(names, curKey), 1);

    % synchronized on Ea
    for i = 1:numel(Ea)
        e = Ea{i};
        post1 = post_states(G1, x1, e);
        post2 = post_states(G2, x2, e);

        for a = 1:numel(post1)
            for b = 1:numel(post2)
                nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{post2(b)}];

                if ~contains_cell(names, nxtKey)
                    if numel(names) >= MAX_STATES
                        terminatedEarly = true;
                        break;
                    end
                    names{end+1} = nxtKey; %#ok<AGROW>
                    queue{end+1} = nxtKey; %#ok<AGROW>
                end

                nxtIdx = find(strcmp(names, nxtKey), 1);

                if numel(from) >= MAX_EDGES
                    terminatedEarly = true;
                    break;
                end

                from(end+1,1) = curIdx; %#ok<AGROW>
                to(end+1,1) = nxtIdx; %#ok<AGROW>
                event{end+1,1} = e; %#ok<AGROW>
            end
            if terminatedEarly, break; end
        end
        if terminatedEarly, break; end
    end

    if terminatedEarly, break; end

    % asynchronous on Euo
    for i = 1:numel(Euo)
        e = Euo{i};

        post1 = post_states(G1, x1, e);
        for a = 1:numel(post1)
            nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{x2}];

            if ~contains_cell(names, nxtKey)
                if numel(names) >= MAX_STATES
                    terminatedEarly = true;
                    break;
                end
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end

            nxtIdx = find(strcmp(names, nxtKey), 1);

            if numel(from) >= MAX_EDGES
                terminatedEarly = true;
                break;
            end

            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end
        if terminatedEarly, break; end

        post2 = post_states(G2, x2, e);
        for b = 1:numel(post2)
            nxtKey = [G1.state_names{x1}, '|', G2.state_names{post2(b)}];

            if ~contains_cell(names, nxtKey)
                if numel(names) >= MAX_STATES
                    terminatedEarly = true;
                    break;
                end
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end

            nxtIdx = find(strcmp(names, nxtKey), 1);

            if numel(from) >= MAX_EDGES
                terminatedEarly = true;
                break;
            end

            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end
        if terminatedEarly, break; end
    end
end

allEvents = union_cell(Ea, Euo);
GVA = new_automaton(names, allEvents, x0Key);
GVA.from = from;
GVA.to = to;
GVA.event = event;
GVA.terminatedEarly = terminatedEarly;
GVA = finalize_automaton(GVA);

end

%% ============================================================
%% Generic automaton utilities
%% ============================================================
function G = new_automaton(state_names, events, x0_name)

G.state_names = state_names(:)';
G.events = events(:)';
G.n = numel(state_names);
G.x0 = find(strcmp(G.state_names, x0_name), 1);

G.from = [];
G.to = [];
G.event = {};
G.marked = false(G.n,1);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);

end

function G = add_transition(G, fromName, e, toName)

fi = state_index(G, fromName);
ti = state_index(G, toName);

G.from(end+1,1) = fi;
G.to(end+1,1) = ti;
G.event{end+1,1} = e;

end

function idx = state_index(G, name)

idx = find(strcmp(G.state_names, name), 1);
if isempty(idx)
    error('State "%s" not found.', name);
end

end

function idx = event_pos(events, e)

idx = find(strcmp(events, e), 1);
if isempty(idx)
    error('Event "%s" not found.', e);
end

end

function G = finalize_automaton(G)

G.n = numel(G.state_names);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);

for i = 1:numel(G.from)
    G.out{G.from(i)}(end+1) = i;
    G.in{G.to(i)}(end+1) = i;
end

if ~isfield(G, 'marked') || numel(G.marked) ~= G.n
    G.marked = false(G.n,1);
end

end

function vec = post_states(G, x, e)

vec = [];
outIdx = G.out{x};
for k = 1:numel(outIdx)
    t = outIdx(k);
    if strcmp(G.event{t}, e)
        vec(end+1) = G.to(t); %#ok<AGROW>
    end
end

end

function Gsub = induced_subautomaton(G, keepIdx)

keepIdx = unique(keepIdx(:)');
map = zeros(G.n,1);
map(keepIdx) = 1:numel(keepIdx);

if map(G.x0) == 0
    Gsub = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gsub.marked = false(1,1);
    Gsub = finalize_automaton(Gsub);
    return;
end

x0_name = G.state_names{G.x0};
Gsub = new_automaton(G.state_names(keepIdx), G.events, x0_name);
Gsub.marked = G.marked(keepIdx);

for i = 1:numel(G.from)
    if map(G.from(i)) > 0 && map(G.to(i)) > 0
        Gsub.from(end+1,1) = map(G.from(i)); %#ok<AGROW>
        Gsub.to(end+1,1) = map(G.to(i)); %#ok<AGROW>
        Gsub.event{end+1,1} = G.event{i}; %#ok<AGROW>
    end
end

Gsub = finalize_automaton(Gsub);

end

function Gacc = accessible_subautomaton(G)

vis = false(G.n,1);
Q = G.x0;
vis(G.x0) = true;
head = 1;

while head <= numel(Q)
    x = Q(head);
    head = head + 1;

    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        y = G.to(outIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end

Gacc = induced_subautomaton(G, find(vis));

end

function Gco = coaccessible_subautomaton(G)

marked = find(G.marked);

if isempty(marked)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end

vis = false(G.n,1);
Q = marked(:)';
vis(marked) = true;
head = 1;

while head <= numel(Q)
    x = Q(head);
    head = head + 1;

    inIdx = G.in{x};
    for k = 1:numel(inIdx)
        y = G.from(inIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end

if ~vis(G.x0)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end

Gco = induced_subautomaton(G, find(vis));

end

function Gtrim = trim_automaton(G)

G1 = accessible_subautomaton(G);
Gtrim = coaccessible_subautomaton(G1);

end

function Gout = remove_outgoing_from_states(G, stateIdx)

mask = true(numel(G.from),1);
stateIdx = unique(stateIdx(:)');

for i = 1:numel(G.from)
    if ismember(G.from(i), stateIdx)
        mask(i) = false;
    end
end

Gout = G;
Gout.from = G.from(mask);
Gout.to   = G.to(mask);
Gout.event = G.event(mask);
Gout = finalize_automaton(Gout);

end

%% ============================================================
%% Small helpers
%% ============================================================
function tf = contains_cell(C, x)
tf = any(strcmp(C, x));
end

function out = union_cell(A, B)

if isempty(A) && isempty(B)
    out = {};
    return;
end

if isempty(A)
    out = B(:)';
    return;
end

if isempty(B)
    out = A(:)';
    return;
end

out = unique([A(:); B(:)]', 'stable');

end

function s = ternary(cond, a, b)
if cond
    s = a;
else
    s = b;
end
end

function [xName, lbl] = split_labeled_state(key)
lbl = key(end);
xName = key(1:end-1);
end