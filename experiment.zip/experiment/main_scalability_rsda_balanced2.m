function main_scalability_rsda_balanced2()
clc; clear; close all;
rng(1);

% ============================================================
% Configuration
% Goal: among 50 runs, most |G_v| are tens/hundreds, only a few thousands,
% and no single-digit verifier sizes are kept.
% ============================================================
numRuns = 50;
maxTriesPerRun = 80;

% quota design: 16 tens, 30 hundreds, 4 thousands
quotaTens = 16;
quotaHundreds = 30;
quotaThousands = 4;
assert(quotaTens + quotaHundreds + quotaThousands == numRuns);

targetBucket = [repmat({'tens'},1,quotaTens), ...
                repmat({'hundreds'},1,quotaHundreds), ...
                repmat({'thousands'},1,quotaThousands)];
targetBucket = targetBucket(randperm(numRuns));

results = struct();
row = 0;

fprintf('Running balanced scalability experiment with RDA and RSDA...\n');

for runId = 1:numRuns
    collected = false;
    tries = 0;
    bucket = targetBucket{runId};

    while ~collected && tries < maxTriesPerRun
        tries = tries + 1;

        % choose plant size and generation parameters according to target bucket
        cfg = bucket_config(bucket);
        N = randi(cfg.N_range);
        G = generate_structured_prognosable_plant_parametric(N, cfg);

        % nominal check: keep only prog = 1
        tJ = tic;
        R_nom = check_rda(G, {}, {});
        TJ = toc(tJ);
        nominalTooLarge = isfield(R_nom.Gv,'terminatedEarly') && R_nom.Gv.terminatedEarly;
        if nominalTooLarge || ~R_nom.rda
            continue;
        end

        % attack scenario guided by target bucket
        [Eera, Eins, attackMode] = generate_attack_scenario_guided(G, bucket);

        % all-attacks verifier (RDA)
        tA = tic;
        R_all = check_rda(G, Eera, Eins);
        TA = toc(tA);
        tooLargeRDA = isfield(R_all.Gv,'terminatedEarly') && R_all.Gv.terminatedEarly;
        if tooLargeRDA
            continue;
        end

        gv = R_all.Gv.n;
        tv = numel(R_all.Gv.from);

        % keep only desired verifier-size region; reject single-digit Gv
        if gv < 20 || gv > 2800 || tv > 22000
            continue;
        end
        if ~bucket_accept(gv, bucket)
            continue;
        end

        % stealthy branch (RSDA)
        tR = tic;
        R_st = check_rsda_simplified(G, Eera, Eins);
        TR = toc(tR);
        tooLargeRSDA = isfield(R_st.Gsv,'terminatedEarly') && R_st.Gsv.terminatedEarly;
        if tooLargeRSDA || R_st.Gsv.n < 6 || R_st.Gsv.n > 2800 || numel(R_st.Gsv.from) > 22000
            continue;
        end

        collected = true;
        row = row + 1;
        results(row).Runs = runId;
        results(row).X = G.n;
        results(row).E = numel(G.events);
        results(row).T = numel(G.from);
        results(row).Eo = numel(G.Eo);
        results(row).Eins = numel(Eins);
        results(row).Eera = numel(Eera);
        results(row).Gv = gv;
        results(row).TJ = TJ;
        results(row).RDA = double(R_all.rda);
        results(row).TR = TR;
        results(row).Gsv = R_st.Gsv.n;
        results(row).RSDA = double(R_st.rsda);
        results(row).TA = TA + TR;
        results(row).mode = {attackMode};
        results(row).target = {bucket};
        results(row).Eins_set = {strjoin(Eins, ',')};
        results(row).Eera_set = {strjoin(Eera, ',')};
        results(row).prog = 1;

        fprintf(['Run %2d [%s]: |X|=%3d, |T|=%3d, |Gv|=%4d, RDA=%d, ' ...
                 '|Gsv|=%4d, RSDA=%d, mode=%s\n'], ...
                 runId, bucket, G.n, numel(G.from), gv, R_all.rda, ...
                 R_st.Gsv.n, R_st.rsda, attackMode);
    end

    if ~collected
        warning('Run %d: no admissible instance found in %d tries. Relaxing with fallback sample.', runId, maxTriesPerRun);
        % fallback: reuse a guaranteed non-single-digit sample with only loose constraints
        [resRow, ok] = fallback_instance(runId, bucket, maxTriesPerRun);
        if ok
            row = row + 1;
            results(row) = resRow;
            fprintf('Run %2d [fallback-%s]: |X|=%3d, |T|=%3d, |Gv|=%4d, RDA=%d, |Gsv|=%4d, RSDA=%d\n', ...
                resRow.Runs, bucket, resRow.X, resRow.T, resRow.Gv, resRow.RDA, resRow.Gsv, resRow.RSDA);
        else
            error('Failed to generate fallback sample for run %d.', runId);
        end
    end
end

T = struct2table(results);
T = T(:, {'Runs','X','E','T','Eo','Eins','Eera','Gv','TJ','RDA','TR','Gsv','RSDA','TA','mode','target','Eins_set','Eera_set','prog'});
T.Properties.VariableNames = {'Runs','|X|','|E|','|T|','|E_o|','|E_ins|','|E_era|','|G_v|','T_J_s','RDA','T_R_s','|G_sv|','RSDA','T_A_s','mode','target_bucket','Eins_set','Eera_set','prog'};

fprintf('\n=== Raw results (all rows) ===\n');
disp(T);

summary_tbl = make_summary_table_rsda(T);
fprintf('\n=== Aggregated summary by |X| bins ===\n');
disp(summary_tbl);

plot_scalability_results_rsda(T);

writetable(T, 'scalability_results_rsda.csv');
writetable(summary_tbl, 'scalability_summary_rsda.csv');
export_results_to_latex_rsda(T, 'scalability_results_rsda.tex');

fprintf('\nSaved:\n');
fprintf('  scalability_results_rsda.csv\n');
fprintf('  scalability_summary_rsda.csv\n');
fprintf('  scalability_results_rsda.tex\n');
end

%% ============================================================
function cfg = bucket_config(bucket)
switch bucket
    case 'tens'
        cfg.N_range = [40 70];
        cfg.ambProb = 0.18;
        cfg.returnNormalProb = 0.92;
        cfg.extraEdgeProb = 0.08;
    case 'hundreds'
        cfg.N_range = [55 95];
        cfg.ambProb = 0.30;
        cfg.returnNormalProb = 0.82;
        cfg.extraEdgeProb = 0.18;
    case 'thousands'
        cfg.N_range = [80 120];
        cfg.ambProb = 0.42;
        cfg.returnNormalProb = 0.70;
        cfg.extraEdgeProb = 0.30;
    otherwise
        error('Unknown bucket');
end
end

function tf = bucket_accept(gv, bucket)
switch bucket
    case 'tens'
        tf = (gv >= 20 && gv <= 99);
    case 'hundreds'
        tf = (gv >= 100 && gv <= 999);
    case 'thousands'
        tf = (gv >= 1000 && gv <= 2800);
    otherwise
        tf = false;
end
end

function [Eera, Eins, attackMode] = generate_attack_scenario_guided(G, bucket)
switch bucket
    case 'tens'
        r = rand;
        if r < 0.85
            attackMode = 'benign';
            eraPool = intersect(G.Eo, {'c','e','w'});
            insPool = intersect(G.Eo, {'b','c','w'});
            if isempty(eraPool), eraPool = G.Eo; end
            if isempty(insPool), insPool = G.Eo; end
            Eera = eraPool(randperm(numel(eraPool),1));
            Eins = insPool(randperm(numel(insPool),1));
        else
            attackMode = 'medium';
            eraPool = intersect(G.Eo, {'e','h'});
            insPool = intersect(G.Eo, {'d','e','g'});
            if isempty(eraPool), eraPool = G.Eo; end
            if isempty(insPool), insPool = G.Eo; end
            Eera = eraPool(randperm(numel(eraPool),1));
            if numel(insPool) >= 2
                p = randperm(numel(insPool),2);
                Eins = insPool(p);
            else
                Eins = insPool(randperm(numel(insPool),1));
            end
        end
    case 'hundreds'
        r = rand;
        if r < 0.55
            attackMode = 'benign';
            eraPool = intersect(G.Eo, {'c','e','w'});
            insPool = intersect(G.Eo, {'b','c','e','w'});
            if isempty(eraPool), eraPool = G.Eo; end
            if isempty(insPool), insPool = G.Eo; end
            Eera = eraPool(randperm(numel(eraPool),1));
            Eins = insPool(randperm(numel(insPool),1));
        elseif r < 0.90
            attackMode = 'medium';
            eraPool = intersect(G.Eo, {'e','h'});
            insPool = intersect(G.Eo, {'d','e','g','w'});
            if isempty(eraPool), eraPool = G.Eo; end
            if isempty(insPool), insPool = G.Eo; end
            Eera = eraPool(randperm(numel(eraPool),1));
            if numel(insPool) >= 2
                p = randperm(numel(insPool),2);
                Eins = insPool(p);
            else
                Eins = insPool(randperm(numel(insPool),1));
            end
        else
            attackMode = 'critical';
            Eera = {'h'};
            Eins = {'g','d'};
        end
    case 'thousands'
        r = rand;
        if r < 0.45
            attackMode = 'medium';
            eraPool = intersect(G.Eo, {'e','h'});
            insPool = intersect(G.Eo, {'d','e','g','w'});
            if isempty(eraPool), eraPool = G.Eo; end
            if isempty(insPool), insPool = G.Eo; end
            Eera = eraPool(randperm(numel(eraPool),1));
            if numel(insPool) >= 2
                p = randperm(numel(insPool),2);
                Eins = insPool(p);
            else
                Eins = insPool(randperm(numel(insPool),1));
            end
        else
            attackMode = 'critical';
            Eera = {'h'};
            Eins = {'g','d'};
        end
    otherwise
        error('Unknown bucket');
end
end

function [resRow, ok] = fallback_instance(runId, bucket, maxTries)
ok = false;
resRow = struct();
for tries = 1:maxTries
    cfg = bucket_config(bucket);
    N = randi(cfg.N_range);
    G = generate_structured_prognosable_plant_parametric(N, cfg);
    tJ = tic; R_nom = check_rda(G, {}, {}); TJ = toc(tJ);
    nominalTooLarge = isfield(R_nom.Gv,'terminatedEarly') && R_nom.Gv.terminatedEarly;
    if nominalTooLarge || ~R_nom.rda
        continue;
    end
    [Eera, Eins, attackMode] = generate_attack_scenario_guided(G, bucket);
    tA = tic; R_all = check_rda(G, Eera, Eins); TA = toc(tA);
    if isfield(R_all.Gv,'terminatedEarly') && R_all.Gv.terminatedEarly
        continue;
    end
    gv = R_all.Gv.n;
    if gv < 20 || gv > 2800
        continue;
    end
    tR = tic; R_st = check_rsda_simplified(G, Eera, Eins); TR = toc(tR);
    if isfield(R_st.Gsv,'terminatedEarly') && R_st.Gsv.terminatedEarly
        continue;
    end
    resRow.Runs = runId;
    resRow.X = G.n;
    resRow.E = numel(G.events);
    resRow.T = numel(G.from);
    resRow.Eo = numel(G.Eo);
    resRow.Eins = numel(Eins);
    resRow.Eera = numel(Eera);
    resRow.Gv = gv;
    resRow.TJ = TJ;
    resRow.RDA = double(R_all.rda);
    resRow.TR = TR;
    resRow.Gsv = R_st.Gsv.n;
    resRow.RSDA = double(R_st.rsda);
    resRow.TA = TA + TR;
    resRow.mode = {attackMode};
    resRow.target = {bucket};
    resRow.Eins_set = {strjoin(Eins, ',')};
    resRow.Eera_set = {strjoin(Eera, ',')};
    resRow.prog = 1;
    ok = true;
    return;
end
end

%% ============================================================
% Parametric plant generator
%% ============================================================
function G = generate_structured_prognosable_plant_parametric(N, cfg)
if N < 18
    error('N must be at least 18.');
end

events = {'a','b','c','d','e','f','g','h','w'};
state_names = arrayfun(@num2str, 1:N, 'UniformOutput', false);

G = new_automaton(state_names, events, '1');
G.Euo = {'a','f'};
G.Eo = setdiff(events, G.Euo, 'stable');
G.Ef = {'f'};
used = false(N, numel(events));

coreT = {
    '1','a','2';
    '2','b','3';
    '3','d','4';
    '4','h','5';
    '5','e','6';
    '6','f','7';
    '4','g','8';
    '8','d','9';
    '9','e','10';
    '4','c','11';
    '11','d','12';
    '12','e','13';
    '10','w','14';
    '14','c','15';
    '15','w','16';
    '16','e','17';
    '17','w','10';
    '13','w','15';
    '14','e','13';
    '16','c','10';
    '17','e','14';
};

for i = 1:size(coreT,1)
    G = add_transition(G, coreT{i,1}, coreT{i,2}, coreT{i,3});
    x = str2double(coreT{i,1});
    e = coreT{i,2};
    used(x, event_pos(G.events, e)) = true;
end

ambiguousSeeds = [3 4 5 8 9 11 12];
normalSeeds    = [10 13 14 15 16 17];
parentCandidates = [ambiguousSeeds, normalSeeds];
attachPoolAmb = {'b','c','d','e','g','h'};
attachPoolNor = {'b','c','d','e','w'};

for x = 18:N
    if rand < cfg.ambProb
        seedPool = ambiguousSeeds;
        attachPool = attachPoolAmb;
    else
        seedPool = normalSeeds;
        attachPool = attachPoolNor;
    end

    possibleParents = [];
    possibleEvents = {};
    for p = 1:numel(seedPool)
        parent = seedPool(p);
        avail = {};
        for k = 1:numel(attachPool)
            e = attachPool{k};
            if ~used(parent, event_pos(G.events, e))
                avail{end+1} = e; %#ok<AGROW>
            end
        end
        if ~isempty(avail)
            possibleParents(end+1) = parent; %#ok<AGROW>
            possibleEvents{end+1} = avail; %#ok<AGROW>
        end
    end

    if isempty(possibleParents)
        for p = 1:numel(parentCandidates)
            parent = parentCandidates(p);
            avail = {};
            for k = 1:numel(G.events)
                e = G.events{k};
                if ~strcmp(e,'f') && ~used(parent, event_pos(G.events, e))
                    avail{end+1} = e; %#ok<AGROW>
                end
            end
            if ~isempty(avail)
                possibleParents(end+1) = parent; %#ok<AGROW>
                possibleEvents{end+1} = avail; %#ok<AGROW>
            end
        end
    end
    if isempty(possibleParents)
        break;
    end

    idx = randi(numel(possibleParents));
    parent = possibleParents(idx);
    avail = possibleEvents{idx};
    eAttach = avail{randi(numel(avail))};
    G = add_transition(G, num2str(parent), eAttach, num2str(x));
    used(parent, event_pos(G.events, eAttach)) = true;

    if rand < cfg.returnNormalProb
        tgtPool = normalSeeds;
    else
        tgtPool = [8 9 11 12 14 15];
    end
    returnCandidates = {'w','c','e','d'};
    for kk = randperm(numel(returnCandidates))
        er = returnCandidates{kk};
        if ~used(x, event_pos(G.events, er))
            tgt = tgtPool(randi(numel(tgtPool)));
            G = add_transition(G, num2str(x), er, num2str(tgt));
            used(x, event_pos(G.events, er)) = true;
            break;
        end
    end

    if rand < cfg.extraEdgeProb
        extraCandidates = {'b','c','d','e','g','h','w'};
        for kk = randperm(numel(extraCandidates))
            e2 = extraCandidates{kk};
            if ~used(x, event_pos(G.events, e2))
                if rand < 0.70
                    tgt2Pool = normalSeeds;
                else
                    tgt2Pool = [4 5 8 9 11 12 14 15];
                end
                tgt2 = tgt2Pool(randi(numel(tgt2Pool)));
                G = add_transition(G, num2str(x), e2, num2str(tgt2));
                used(x, event_pos(G.events, e2)) = true;
                break;
            end
        end
    end

    parentCandidates(end+1) = x; %#ok<AGROW>
    if rand < max(0.10, cfg.ambProb - 0.05)
        ambiguousSeeds(end+1) = x; %#ok<AGROW>
    else
        normalSeeds(end+1) = x; %#ok<AGROW>
    end
end
G = finalize_automaton(G);
end

%% ============================================================
% RDA
%% ============================================================
function R = check_rda(G, Eera, Eins)
faultEvent = 'f';
Gl = build_labeled_plant(G, faultEvent);
GF = build_faulty_part(Gl);
GN = build_normal_part(Gl);

GFA = build_attack_faulty_automaton(GF, Eins, Eera);
postFault = false(GFA.n,1);
for i = 1:numel(GFA.from)
    if strcmp(GFA.event{i}, faultEvent)
        postFault(GFA.to(i)) = true;
    end
end
GFA = remove_outgoing_from_states(GFA, find(postFault));
GFA.marked = postFault;
GFA = trim_automaton(GFA);

GNA = build_attack_normal_automaton(GN, Eins, Eera);
Eminus = strcat(Eera, '_-');
GNA = keep_prefixes_to_nontrivial_scc(GNA, Eminus);

Ea = union_cell(G.Eo, union_cell(strcat(Eins,'_+'), strcat(Eera,'_-')));
Gv = build_attack_aware_parallel(GFA, GNA, Ea, G.Euo);

bad = false(Gv.n,1);
for i = 1:Gv.n
    nm = Gv.state_names{i};
    parts = strsplit(nm, '|');
    left = parts{1};
    if ~isempty(left) && left(end) == 'F'
        bad(i) = true;
    end
end
R.rda = ~any(bad);
R.bad = bad;
R.Gv = Gv;
end

%% ============================================================
% RSDA (simplified experiment version)
%% ============================================================
function R = check_rsda_simplified(G, Eera, Eins)
[Eera_s, Eins_s] = stealthy_subset_simplified(G, Eera, Eins);
faultEvent = 'f';
Gl = build_labeled_plant(G, faultEvent);
GF = build_faulty_part(Gl);
GN = build_normal_part(Gl);

GFA = build_attack_faulty_automaton(GF, Eins_s, Eera_s);
postFault = false(GFA.n,1);
for i = 1:numel(GFA.from)
    if strcmp(GFA.event{i}, faultEvent)
        postFault(GFA.to(i)) = true;
    end
end
GFA = remove_outgoing_from_states(GFA, find(postFault));
GFA.marked = postFault;
GFA = trim_automaton(GFA);

GNA = build_attack_normal_automaton(GN, Eins_s, Eera_s);
Eminus = strcat(Eera_s, '_-');
GNA = keep_prefixes_to_nontrivial_scc(GNA, Eminus);

Ea = union_cell(G.Eo, union_cell(strcat(Eins_s,'_+'), strcat(Eera_s,'_-')));
Gsv = build_attack_aware_parallel(GFA, GNA, Ea, G.Euo);

bad = false(Gsv.n,1);
for i = 1:Gsv.n
    nm = Gsv.state_names{i};
    parts = strsplit(nm, '|');
    left = parts{1};
    if ~isempty(left) && left(end) == 'F'
        bad(i) = true;
    end
end

R.rsda = ~any(bad);
R.bad = bad;
R.Gsv = Gsv;
R.Eera_s = Eera_s;
R.Eins_s = Eins_s;
end

function [Eera_s, Eins_s] = stealthy_subset_simplified(G, Eera, Eins)
normalStealthyPoolEra = intersect(G.Eo, {'h','e'});
normalStealthyPoolIns = intersect(G.Eo, {'g','d'});
Eera_s = intersect(Eera, normalStealthyPoolEra, 'stable');
Eins_s = intersect(Eins, normalStealthyPoolIns, 'stable');
end

%% ============================================================
% Tables and plotting
%% ============================================================
function S = make_summary_table_rsda(T)
X = T.('|X|');
bins = cell(height(T),1);
for i = 1:height(T)
    if X(i) <= 60
        bins{i} = '<=60';
    elseif X(i) <= 80
        bins{i} = '61-80';
    elseif X(i) <= 100
        bins{i} = '81-100';
    else
        bins{i} = '101-120';
    end
end
T.Xbin = bins;

cats = {'<=60','61-80','81-100','101-120'};
numRuns = zeros(numel(cats),1);
meanX = zeros(numel(cats),1);
meanGv = zeros(numel(cats),1);
meanGsv = zeros(numel(cats),1);
meanRDA = zeros(numel(cats),1);
meanRSDA = zeros(numel(cats),1);
meanTA = zeros(numel(cats),1);

for i = 1:numel(cats)
    idx = strcmp(T.Xbin, cats{i});
    if any(idx)
        numRuns(i) = sum(idx);
        meanX(i) = mean(T.('|X|')(idx));
        meanGv(i) = mean(T.('|G_v|')(idx));
        meanGsv(i) = mean(T.('|G_sv|')(idx));
        meanRDA(i) = mean(T.RDA(idx));
        meanRSDA(i) = mean(T.RSDA(idx));
        meanTA(i) = mean(T.T_A_s(idx));
    end
end

S = table(cats', numRuns, meanX, meanGv, meanGsv, meanRDA, meanRSDA, meanTA, ...
    'VariableNames', {'|X|_bin','numRuns','mean_|X|','mean_|G_v|','mean_|G_sv|','mean_RDA','mean_RSDA','mean_T_A_s'});
end

function plot_scalability_results_rsda(T)
figure;
scatter(T.('|X|'), T.('|G_v|'), 35, T.RDA, 'filled');
xlabel('|X|'); ylabel('|G_v|'); title('Verifier size vs. plant size'); grid on;

figure;
scatter(T.('|X|'), T.('|G_sv|'), 35, T.RSDA, 'filled');
xlabel('|X|'); ylabel('|G_{sv}|'); title('Stealthy verifier size vs. plant size'); grid on;
end

function export_results_to_latex_rsda(T, outFile)
if nargin < 2 || isempty(outFile)
    outFile = 'scalability_results_rsda.tex';
end
fid = fopen(outFile, 'w');
if fid == -1
    error('Cannot open output file: %s', outFile);
end
fprintf(fid, '\\begin{table*}\n');
fprintf(fid, '\t\\centering\n');
fprintf(fid, '\t\\caption{Computation statistics of %d randomly generated systems}\n', height(T));
fprintf(fid, '\t\\scalebox{0.82}{\\begin{tabular}{c|c|c|c|c|c|c|c|c|c|c|c|c|c}\n');
fprintf(fid, '\t\t\t\\hline\n');
fprintf(fid, '\t\t\tRuns & $|X|$ & $|E|$ & $|T|$ & $|E_{o}|$ & $|E_{ins}|$ & $|E_{era}|$ & $|G_v|$ & $T_{J}(s)$ & RDA & $T_{R}(s)$ & $|G_{sv}|$ & RSDA & $T_{A}(s)$ \\\\\n');
fprintf(fid, '\t\t\t\\hline\n');
for i = 1:height(T)
    fprintf(fid, '\t\t\t%d & %d & %d & %d & %d & %d & %d & %d & %.4f & %d & %.4f & %d & %d & %.4f \\\\\n', ...
        T.Runs(i), T.('|X|')(i), T.('|E|')(i), T.('|T|')(i), T.('|E_o|')(i), T.('|E_ins|')(i), ...
        T.('|E_era|')(i), T.('|G_v|')(i), T.T_J_s(i), T.RDA(i), T.T_R_s(i), T.('|G_sv|')(i), T.RSDA(i), T.T_A_s(i));
end
fprintf(fid, '\t\t\t\\hline\n');
fprintf(fid, '\t\\end{tabular}}\n');
fprintf(fid, '\\end{table*}\n');
fclose(fid);
end

%% ============================================================
% Generic automaton utilities
%% ============================================================
function G = new_automaton(state_names, events, x0_name)
G.state_names = state_names(:)';
G.events = events(:)';
G.n = numel(state_names);
G.x0 = find(strcmp(G.state_names, x0_name), 1);
G.from = [];
G.to = [];
G.event = {};
G.marked = false(G.n,1);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);
end

function G = add_transition(G, fromName, e, toName)
fi = state_index(G, fromName);
ti = state_index(G, toName);
G.from(end+1,1) = fi;
G.to(end+1,1) = ti;
G.event{end+1,1} = e;
end

function idx = state_index(G, name)
idx = find(strcmp(G.state_names, name), 1);
if isempty(idx)
    error('State "%s" not found.', name);
end
end

function idx = event_pos(events, e)
idx = find(strcmp(events, e), 1);
if isempty(idx)
    error('Event "%s" not found.', e);
end
end

function G = finalize_automaton(G)
G.n = numel(G.state_names);
G.out = cell(G.n,1);
G.in  = cell(G.n,1);
for i = 1:numel(G.from)
    G.out{G.from(i)}(end+1) = i;
    G.in{G.to(i)}(end+1) = i;
end
if ~isfield(G,'marked') || numel(G.marked) ~= G.n
    G.marked = false(G.n,1);
end
end

function vec = post_states(G, x, e)
vec = [];
outIdx = G.out{x};
for k = 1:numel(outIdx)
    t = outIdx(k);
    if strcmp(G.event{t}, e)
        vec(end+1) = G.to(t); %#ok<AGROW>
    end
end
end

function Gsub = induced_subautomaton(G, keepIdx)
keepIdx = unique(keepIdx(:)');
map = zeros(G.n,1);
map(keepIdx) = 1:numel(keepIdx);
if map(G.x0) == 0
    Gsub = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gsub.marked = false(1,1);
    Gsub = finalize_automaton(Gsub);
    return;
end
x0_name = G.state_names{G.x0};
Gsub = new_automaton(G.state_names(keepIdx), G.events, x0_name);
Gsub.marked = G.marked(keepIdx);
for i = 1:numel(G.from)
    if map(G.from(i)) > 0 && map(G.to(i)) > 0
        Gsub.from(end+1,1) = map(G.from(i)); %#ok<AGROW>
        Gsub.to(end+1,1) = map(G.to(i)); %#ok<AGROW>
        Gsub.event{end+1,1} = G.event{i}; %#ok<AGROW>
    end
end
Gsub = finalize_automaton(Gsub);
end

function Gacc = accessible_subautomaton(G)
vis = false(G.n,1);
Q = G.x0;
vis(G.x0) = true;
head = 1;
while head <= numel(Q)
    x = Q(head);
    head = head + 1;
    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        y = G.to(outIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end
Gacc = induced_subautomaton(G, find(vis));
end

function Gco = coaccessible_subautomaton(G)
marked = find(G.marked);
if isempty(marked)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end
vis = false(G.n,1);
Q = marked(:)';
vis(marked) = true;
head = 1;
while head <= numel(Q)
    x = Q(head);
    head = head + 1;
    inIdx = G.in{x};
    for k = 1:numel(inIdx)
        y = G.from(inIdx(k));
        if ~vis(y)
            vis(y) = true;
            Q(end+1) = y; %#ok<AGROW>
        end
    end
end
if ~vis(G.x0)
    Gco = new_automaton({G.state_names{G.x0}}, G.events, G.state_names{G.x0});
    Gco.marked = false(1,1);
    Gco = finalize_automaton(Gco);
    return;
end
Gco = induced_subautomaton(G, find(vis));
end

function Gtrim = trim_automaton(G)
G1 = accessible_subautomaton(G);
Gtrim = coaccessible_subautomaton(G1);
end

function Gout = remove_outgoing_from_states(G, stateIdx)
mask = true(numel(G.from),1);
stateIdx = unique(stateIdx(:)');
for i = 1:numel(G.from)
    if ismember(G.from(i), stateIdx)
        mask(i) = false;
    end
end
Gout = G;
Gout.from = G.from(mask);
Gout.to   = G.to(mask);
Gout.event = G.event(mask);
Gout = finalize_automaton(Gout);
end

function Gl = build_labeled_plant(G, faultEvent)
names = {};
from = [];
to = [];
event = {};
queue = {};
head = 1;
x0_key = [G.state_names{G.x0}, 'N'];
queue{end+1} = x0_key;
names{end+1} = x0_key;
while head <= numel(queue)
    curKey = queue{head};
    head = head + 1;
    [xName, lbl] = split_labeled_state(curKey);
    x = state_index(G, xName);
    curIdx = find(strcmp(names, curKey), 1);
    outIdx = G.out{x};
    for k = 1:numel(outIdx)
        t = outIdx(k);
        e = G.event{t};
        y = G.to(t);
        newLbl = lbl;
        if strcmp(e, faultEvent) || strcmp(lbl, 'F')
            newLbl = 'F';
        end
        nxtKey = [G.state_names{y}, newLbl];
        if ~contains_cell(names, nxtKey)
            names{end+1} = nxtKey; %#ok<AGROW>
            queue{end+1} = nxtKey; %#ok<AGROW>
        end
        nxtIdx = find(strcmp(names, nxtKey), 1);
        from(end+1,1) = curIdx; %#ok<AGROW>
        to(end+1,1) = nxtIdx; %#ok<AGROW>
        event{end+1,1} = e; %#ok<AGROW>
    end
end
Gl = new_automaton(names, G.events, x0_key);
Gl.from = from; Gl.to = to; Gl.event = event;
Gl = finalize_automaton(Gl);
end

function GF = build_faulty_part(Gl)
isFault = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'F'
        isFault(i) = true;
    end
end
Gl.marked = isFault;
GF = coaccessible_subautomaton(Gl);
end

function GN = build_normal_part(Gl)
keep = false(Gl.n,1);
for i = 1:Gl.n
    nm = Gl.state_names{i};
    if ~isempty(nm) && nm(end) == 'N'
        keep(i) = true;
    end
end
GN = induced_subautomaton(Gl, find(keep));
mask = true(numel(GN.event),1);
for i = 1:numel(GN.event)
    if strcmp(GN.event{i}, 'f')
        mask(i) = false;
    end
end
GN.from  = GN.from(mask);
GN.to    = GN.to(mask);
GN.event = GN.event(mask);
GN = finalize_automaton(GN);
GN.marked = true(GN.n,1);
end

function GFA = build_attack_faulty_automaton(GF, Eins, Eera)
Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GF.events, union_cell(Eplus, Eminus));
GFA = new_automaton(GF.state_names, Ew, GF.state_names{GF.x0});
GFA.from = GF.from; GFA.to = GF.to; GFA.event = GF.event;
for x = 1:GF.n
    for i = 1:numel(Eins)
        GFA = add_transition(GFA, GF.state_names{x}, [Eins{i}, '_+'], GF.state_names{x});
    end
end
for t = 1:numel(GF.from)
    e = GF.event{t};
    if ismember(e, Eera)
        GFA = add_transition(GFA, GF.state_names{GF.from(t)}, [e, '_-'], GF.state_names{GF.to(t)});
    end
end
GFA = finalize_automaton(GFA);
end

function GNA = build_attack_normal_automaton(GN, Eins, Eera)
Eplus  = strcat(Eins, '_+');
Eminus = strcat(Eera, '_-');
Ew = union_cell(GN.events, union_cell(Eplus, Eminus));
GNA = new_automaton(GN.state_names, Ew, GN.state_names{GN.x0});
GNA.from = GN.from; GNA.to = GN.to; GNA.event = GN.event;
for x = 1:GN.n
    for i = 1:numel(Eera)
        GNA = add_transition(GNA, GN.state_names{x}, [Eera{i}, '_-'], GN.state_names{x});
    end
end
for t = 1:numel(GN.from)
    e = GN.event{t};
    if ismember(e, Eins)
        GNA = add_transition(GNA, GN.state_names{GN.from(t)}, [e, '_+'], GN.state_names{GN.to(t)});
    end
end
GNA = finalize_automaton(GNA);
end

function Gout = keep_prefixes_to_nontrivial_scc(GNA, Eminus)
mask = true(numel(GNA.from),1);
for i = 1:numel(GNA.from)
    if ismember(GNA.event{i}, Eminus)
        mask(i) = false;
    end
end
A = sparse(GNA.from(mask), GNA.to(mask), 1, GNA.n, GNA.n);
DG = digraph(A);
comp = conncomp(DG, 'Type', 'strong');
numC = max(comp);
marked = false(GNA.n,1);
for c = 1:numC
    nodes = find(comp == c);
    if numel(nodes) > 1
        marked(nodes) = true;
    else
        x = nodes(1);
        if A(x,x) ~= 0
            marked(x) = true;
        end
    end
end
GNA.marked = marked;
Gout = coaccessible_subautomaton(GNA);
end

function GVA = build_attack_aware_parallel(G1, G2, Ea, Euo)
MAX_STATES = 2800;
MAX_EDGES  = 22000;

names = {};
from = [];
to = [];
event = {};
queue = {};
head = 1;
x0Key = [G1.state_names{G1.x0}, '|', G2.state_names{G2.x0}];
names{1} = x0Key;
queue{1} = x0Key;
terminatedEarly = false;

while head <= numel(queue)
    if numel(names) >= MAX_STATES || numel(from) >= MAX_EDGES
        terminatedEarly = true;
        break;
    end
    curKey = queue{head};
    head = head + 1;
    parts = strsplit(curKey, '|');
    x1 = state_index(G1, parts{1});
    x2 = state_index(G2, parts{2});
    curIdx = find(strcmp(names, curKey), 1);

    for i = 1:numel(Ea)
        e = Ea{i};
        post1 = post_states(G1, x1, e);
        post2 = post_states(G2, x2, e);
        for a = 1:numel(post1)
            for b = 1:numel(post2)
                nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{post2(b)}];
                if ~contains_cell(names, nxtKey)
                    if numel(names) >= MAX_STATES
                        terminatedEarly = true; break;
                    end
                    names{end+1} = nxtKey; %#ok<AGROW>
                    queue{end+1} = nxtKey; %#ok<AGROW>
                end
                nxtIdx = find(strcmp(names, nxtKey), 1);
                if numel(from) >= MAX_EDGES
                    terminatedEarly = true; break;
                end
                from(end+1,1) = curIdx; %#ok<AGROW>
                to(end+1,1) = nxtIdx; %#ok<AGROW>
                event{end+1,1} = e; %#ok<AGROW>
            end
            if terminatedEarly, break; end
        end
        if terminatedEarly, break; end
    end
    if terminatedEarly, break; end

    for i = 1:numel(Euo)
        e = Euo{i};
        post1 = post_states(G1, x1, e);
        for a = 1:numel(post1)
            nxtKey = [G1.state_names{post1(a)}, '|', G2.state_names{x2}];
            if ~contains_cell(names, nxtKey)
                if numel(names) >= MAX_STATES
                    terminatedEarly = true; break;
                end
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end
            nxtIdx = find(strcmp(names, nxtKey), 1);
            if numel(from) >= MAX_EDGES
                terminatedEarly = true; break;
            end
            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end
        if terminatedEarly, break; end

        post2 = post_states(G2, x2, e);
        for b = 1:numel(post2)
            nxtKey = [G1.state_names{x1}, '|', G2.state_names{post2(b)}];
            if ~contains_cell(names, nxtKey)
                if numel(names) >= MAX_STATES
                    terminatedEarly = true; break;
                end
                names{end+1} = nxtKey; %#ok<AGROW>
                queue{end+1} = nxtKey; %#ok<AGROW>
            end
            nxtIdx = find(strcmp(names, nxtKey), 1);
            if numel(from) >= MAX_EDGES
                terminatedEarly = true; break;
            end
            from(end+1,1) = curIdx; %#ok<AGROW>
            to(end+1,1) = nxtIdx; %#ok<AGROW>
            event{end+1,1} = e; %#ok<AGROW>
        end
        if terminatedEarly, break; end
    end
end

allEvents = union_cell(Ea, Euo);
GVA = new_automaton(names, allEvents, x0Key);
GVA.from = from; GVA.to = to; GVA.event = event;
GVA.terminatedEarly = terminatedEarly;
GVA = finalize_automaton(GVA);
end

function tf = contains_cell(C, x)
tf = any(strcmp(C, x));
end

function out = union_cell(A, B)
if isempty(A) && isempty(B)
    out = {};
elseif isempty(A)
    out = B(:)';
elseif isempty(B)
    out = A(:)';
else
    out = unique([A(:); B(:)]', 'stable');
end
end

function [xName, lbl] = split_labeled_state(key)
lbl = key(end);
xName = key(1:end-1);
end
